ARQ_API_BASE_URL = "https://thearq.tech"
