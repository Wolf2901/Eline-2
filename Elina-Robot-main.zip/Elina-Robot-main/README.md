## 𝑬𝒍𝒊𝒏𝒆 ʀᴏʙᴏᴛ

<p align="center">
  <img src="https://te.legra.ph/file/ac7165a6fb135f852076b.jpg">
</p>

ғᴏʀ ǫᴜᴇʀɪᴇs ᴏʀ ᴀɴʏ ɪssᴜᴇs ʀᴇɢᴀʀᴅɪɴɢ ᴛʜᴇ ʙᴏᴛ ᴛʜᴇɴ ᴄᴏɴᴛᴀᴄᴛ ᴏᴜʀ sᴜᴘᴘᴏʀᴛ ɢʀᴏᴜᴘ [ 𝑬𝒍𝒊𝒏𝒆 sᴜᴘᴘᴏʀᴛ](https://t.me/Eline_Support)
 
## ᴅᴇᴘʟᴏʏ ᴛᴏ ʜᴇʀᴏᴋᴜ
<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/Wolf2901/Elina-Robot"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>


## ᴄʜᴀɴɴᴇʟ ᴀɴᴅ sᴜᴘᴘᴏʀᴛ

* [Total Masti](https://t.me/+E4_H_EB48IUwYTI1)
* [Eline](https://telegram.dog/Elina_Support)
* [Mine Bots](https://t.me/Mine_All_Bots)






