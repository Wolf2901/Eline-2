
__help__ = """
*Fun Gifs and Images:*
 • `/pat`*:* pats a user by a reply to the message.
 • `/neko`*:* sends random neko image
 • `/hug`*:* sends random hug gif
 • `/tickle`*:* sends random tickle gif
 • `/feed`*:* sends random feed gif
 • `/poke`*:* sends random poke gif
 • `/waifu`*:* sends random waifu sticker/image
 • `/kiss`*:* sends random kiss gif
 • `/baka`*:* sends random baka gif
 • `/smug`*:* sends random smug gif
 • `/foxgirl`*:* sends random foxgirl image
 • `/feed`*:* sends random feed gif
 • `/wallpaper`*:* sends random best anime wallpapers.
 

*Style your text with Elina!*
 • `/weebify <text>`*:* weebify your text!
 • `/bubble <text>`*:* bubble your text!
 • `/fbubble <text>`*:* bubble-filled your text!
 • `/square <text>`*:* square your text!
 • `/fsquare <text>`*:* square-filled your text!
 • `/blue <text>`*:* bluify your text!
 • `/latin <text>`*:* latinify your text!
 • `/lined <text>`*:* lined your text!
 • `/plet <text> `*:* text get funny emojify.
 
 *Truth And Dare*
 • `/Truth`*:* for random truth.
 • `/dare`*:* for random dare.
"""


__mod_name__ = "𝑬𝒍𝒊𝒏𝒆 ʜᴇʟᴘ"
